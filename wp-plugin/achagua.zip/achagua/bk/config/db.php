<?php
/*
return [
    'host'   => 'localhost',
    'user'   => 'marcoher_achagua',
    'pwd'    => 'hbIEHJ2QoQH~',
    'schema' => 'marcoher_achagua'
];*/
return [
    'host'   => 'siteground322.com',
    'user'   => 'securiz4_achagua',
    'pwd'    => '8#9Ae&czTBQt',
    'schema' => 'securiz4_achagua'
];
?>